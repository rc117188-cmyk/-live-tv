package com.bengalibharat.livetv;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final List<Channel> channels = new ArrayList<>();
    private LinearLayout channelList;
    private EditText searchBox;

    private static class Channel {
        final String name;
        final String category;
        final String url;
        Channel(String name, String category, String url) {
            this.name = name;
            this.category = category;
            this.url = url;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addChannels();
        buildScreen();
        renderChannels("");
    }

    private void addChannels() {
        channels.add(new Channel("দূরদর্শন বাংলা (DD Bangla)", "বাংলা • সরকারি", "https://prasarbharati.gov.in/"));
        channels.add(new Channel("দূরদর্শন ন্যাশনাল (DD National)", "হিন্দি • বিনোদন", "https://prasarbharati.gov.in/"));
        channels.add(new Channel("DD News", "সংবাদ", "https://prasarbharati.gov.in/"));
        channels.add(new Channel("Sansad TV", "সংসদ ও সংবাদ", "https://sansadtv.nic.in/"));
        channels.add(new Channel("ABP Ananda", "বাংলা • সংবাদ", "https://www.abpananda.abplive.com/"));
        channels.add(new Channel("News18 বাংলা", "বাংলা • সংবাদ", "https://bengali.news18.com/"));
        channels.add(new Channel("TV9 বাংলা", "বাংলা • সংবাদ", "https://tv9bangla.com/"));
        channels.add(new Channel("Zee 24 ঘণ্টা", "বাংলা • সংবাদ", "https://zeenews.india.com/bengali/"));
    }

    private void buildScreen() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(20), dp(18), dp(16));
        page.setBackgroundColor(Color.rgb(10, 18, 35));

        TextView title = new TextView(this);
        title.setText("বাংলা ভারত Live TV");
        title.setTextColor(Color.WHITE);
        title.setTextSize(25);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        page.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("ভারতের টিভি চ্যানেলের অফিসিয়াল পেজ এক জায়গায়");
        subtitle.setTextColor(Color.rgb(190, 205, 225));
        subtitle.setTextSize(14);
        subtitle.setPadding(0, dp(6), 0, dp(16));
        page.addView(subtitle);

        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setTextColor(Color.WHITE);
        searchBox.setHintTextColor(Color.rgb(170, 180, 198));
        searchBox.setHint("চ্যানেল খুঁজুন...");
        searchBox.setTextSize(15);
        searchBox.setPadding(dp(14), dp(10), dp(14), dp(10));
        searchBox.setBackground(roundBg(Color.rgb(29, 42, 65), dp(12)));
        page.addView(searchBox, new LinearLayout.LayoutParams(-1, dp(50)));

        TextView note = new TextView(this);
        note.setText("চ্যানেল খুলতে কার্ডে চাপ দিন। অফিসিয়াল ওয়েবসাইট ব্রাউজারে খুলবে।");
        note.setTextColor(Color.rgb(190, 205, 225));
        note.setTextSize(12);
        note.setPadding(0, dp(12), 0, dp(12));
        page.addView(note);

        ScrollView scroll = new ScrollView(this);
        channelList = new LinearLayout(this);
        channelList.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(channelList);
        page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        TextView footer = new TextView(this);
        footer.setText("নোট: সব চ্যানেলের লাইভ সম্প্রচার সবসময় উপলভ্য নাও থাকতে পারে।");
        footer.setTextColor(Color.rgb(145, 160, 182));
        footer.setTextSize(11);
        footer.setPadding(0, dp(10), 0, 0);
        page.addView(footer);

        setContentView(page);

        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                renderChannels(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private void renderChannels(String query) {
        channelList.removeAllViews();
        String q = query.toLowerCase(Locale.ROOT).trim();
        int shown = 0;
        for (Channel channel : channels) {
            if (!channel.name.toLowerCase(Locale.ROOT).contains(q)
                    && !channel.category.toLowerCase(Locale.ROOT).contains(q)) continue;

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(16), dp(14), dp(16), dp(14));
            card.setBackground(roundBg(Color.rgb(22, 34, 55), dp(14)));
            card.setClickable(true);
            card.setFocusable(true);

            TextView name = new TextView(this);
            name.setText(channel.name);
            name.setTextColor(Color.WHITE);
            name.setTextSize(17);
            name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            card.addView(name);

            TextView category = new TextView(this);
            category.setText(channel.category + "  •  অফিসিয়াল পেজ");
            category.setTextColor(Color.rgb(172, 190, 215));
            category.setTextSize(12);
            category.setPadding(0, dp(5), 0, 0);
            card.addView(category);

            TextView open = new TextView(this);
            open.setText("ওয়েবসাইট খুলুন  ↗");
            open.setTextColor(Color.rgb(255, 190, 90));
            open.setTextSize(13);
            open.setPadding(0, dp(10), 0, 0);
            card.addView(open);

            card.setOnClickListener(v -> openChannel(channel.url));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.bottomMargin = dp(10);
            channelList.addView(card, lp);
            shown++;
        }

        if (shown == 0) {
            TextView empty = new TextView(this);
            empty.setText("কোনো চ্যানেল পাওয়া যায়নি।");
            empty.setTextColor(Color.WHITE);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(24), 0, dp(24));
            channelList.addView(empty);
        }
    }

    private void openChannel(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "ওয়েবসাইট খোলা যায়নি।", Toast.LENGTH_SHORT).show();
        }
    }

    private GradientDrawable roundBg(int color, int radius) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(radius);
        return bg;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
