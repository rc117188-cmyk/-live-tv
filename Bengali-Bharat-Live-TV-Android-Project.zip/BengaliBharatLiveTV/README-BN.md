# Bengali Bharat Live TV — Android project

এটি একটি Android starter app। এতে কয়েকটি ভারতীয় টিভি চ্যানেলের **অফিসিয়াল ওয়েবসাইটের লিংক** দেওয়া আছে। কার্ডে চাপ দিলে সংশ্লিষ্ট ওয়েবসাইট ফোনের ব্রাউজারে খুলবে।

## গুরুত্বপূর্ণ
- এই অ্যাপ কোনো অননুমোদিত বা পাইরেটেড TV stream সরবরাহ করে না।
- অফিসিয়াল ওয়েবসাইটে লাইভ ভিডিও সবসময় বা সব দেশে উপলভ্য নাও থাকতে পারে।
- চ্যানেলের নাম/লিংক তাদের নিজ নিজ মালিকের। এই অ্যাপ তাদের সঙ্গে অনুমোদিত বা সংযুক্ত নয়।
- Play Store-এ প্রকাশের আগে প্রতিটি লিংকের অনুমতি, গোপনীয়তা নীতি, কনটেন্ট রেটিং ও স্টোর নীতি যাচাই করতে হবে।

## GitHub থেকে AAB তৈরি (শুধু Android ফোন)
1. ZIP ফাইলটি extract না করেও GitHub repository-তে আপলোডের জন্য আগে ফোনে ZIP extract করুন।
2. Repository `bharat-live-tv` খুলুন।
3. **Add file → Upload files** চাপুন।
4. ZIP-এর ভেতরের ফাইল ও `.github` ফোল্ডারসহ সব project files upload করুন। ZIP ফাইলটিকে একা upload করবেন না।
5. নিচে গিয়ে **Commit changes** চাপুন।
6. Repository-র **Actions** tab খুলুন। `Build Bengali Bharat Live TV AAB` workflow চলবে।
7. সবুজ tick এলে workflow run খুলে **Artifacts** থেকে `Bengali-Bharat-Live-TV-AAB` ডাউনলোড করুন।
8. ZIP artifact extract করলে `app-release.aab` পাওয়া যাবে।

## Build configuration
- Android Gradle Plugin: 9.4.0
- Gradle: 9.6.0
- Java: 17
- compileSdk / targetSdk: 36
- minSdk: 23

এটি unsigned release AAB তৈরি করে। Google Play-তে প্রকাশের আগে Play Console-এর App signing ধাপ সম্পন্ন করতে হবে।
